import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import FulfillerDashboard  from './pages/FulfillerDashboard';
import CustomerDashboard from './pages/CustomerDashboard';
import Incident from './pages/CreateIncident';
import Login from './pages/LoginPage';
import Signup from './pages/Signup';
import Master from './pages/master';
import View from './pages/view';
import Edit from './pages/edit';
import Dashboard from './pages/Dashboard';

const PrivateRoute = ({ element: Element, ...rest }) => {
  const token = localStorage.getItem('token');
  return token ? <Element {...rest} /> : <Navigate to="/" />;
};


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
        <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/ann" element={<PrivateRoute element={FulfillerDashboard} />} />
          <Route path="/home" element={<PrivateRoute element={CustomerDashboard} />} />
          <Route path="/newIncident" element={<PrivateRoute element={Incident} />} />
          <Route path="/master" element={<PrivateRoute element={Master} />} />
          <Route path="/view" element={<PrivateRoute element={View} />} />
          <Route path="/edit/:inc_number" element={<PrivateRoute element={Edit} />} />
          <Route path="/dasboard" element={<Dashboard />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
