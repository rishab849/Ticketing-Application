import React from 'react';
import { useNavigate } from 'react-router-dom';
import logo from '../assets/esslogo.png';
import '../css/navbar.css';

export const Navbar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  return (
    <div>
      <header className="header">
        <div className="logo">
          <a href="/home">
            <img src={logo} className="ess" alt="Logo" />
          </a>
        </div>
        <button className="logoutbutton" onClick={handleLogout}>
          Logout
        </button>
      </header>
    </div>
  );
};
