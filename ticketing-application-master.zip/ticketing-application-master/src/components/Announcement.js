import React from 'react';

export const Announcement = () => {
  return (
    <div>
      <div class="p-2" style={{borderBottom:`solid 1px grey`}}>
        <li class="list-group-item bg-trans" style={{border:`none`,color:`#fff`}}>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolorem, molestias. Suscipit fuga quaerat eaque consequuntur.</li>
        <div class="justify-space-between">
            <div class="d-flex justify-content-between">
              <p class="m-2 text-muted">Maintenance</p>
              <p class="m-2 text-muted">2 days ago</p>
            </div>
        </div>
      </div>
      <div class="p-2" style={{borderBottom:`solid 1px grey`}}>
        <li class="list-group-item bg-trans" style={{border:`none`,color:`#fff`}}>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolorem, molestias. Suscipit fuga quaerat eaque consequuntur.</li>
        <div class="justify-space-between">
            <div class="d-flex justify-content-between">
              <p class="m-2 text-muted">Maintenance</p>
              <p class="m-2 text-muted">2 days ago</p>
            </div>
        </div>
      </div>
    </div>
  )
}
