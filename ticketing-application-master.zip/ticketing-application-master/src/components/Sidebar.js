import React, { useState } from 'react';
import '../css/sidebar.css';

export const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div>
      <div className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="hamburger" onClick={toggleSidebar}>
          <div className="line"></div>
          <div className="line"></div>
          <div className="line"></div>
        </div>
        <div className={`sidebar-content ${isOpen ? 'visible' : ''}`}>
          <ul className="nav nav-pills nav-flush flex-column mb-auto text-center">
            <li className="nav-item">
              <a href="/home" className="nav-link py-3 border-bottom">
                Home
              </a>
            </li>
            <li>
              <a href="/master" className="nav-link py-3 border-bottom">
                Master pages
              </a>
            </li>
            <li>
              <a href="/newIncident" className="nav-link py-3 border-bottom">
                Create Incident
              </a>
            </li>
            <li>
              <a href="/ann" className="nav-link py-3 border-bottom">
                Announcement
              </a>
            </li>
            <li>
              <a href="/view" className="nav-link py-3 border-bottom">
                View Incidents
              </a>
            </li>
            <li>
              <a href="/dasboard" className="nav-link py-3 border-bottom">
                Dashboard
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
