import React from 'react'
import { Announcement } from './Announcement'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleLeft,faCircleRight} from '@fortawesome/free-regular-svg-icons';

export const Pagination = () => {
  return (
    <div>
        <div class="card bg-trans" >
            <div className="d-flex justify-content-between">
                <p class="m-2 t-white">Announcement</p>
                <p class="m-2 t-white p-1"><FontAwesomeIcon icon={faCircleLeft} /> 2 of 15 <FontAwesomeIcon icon={faCircleRight} /></p> 
            </div>
            <ul class="list-group list-group-flush">
                <Announcement/>
            </ul>
        </div>
    </div>
  )
}
