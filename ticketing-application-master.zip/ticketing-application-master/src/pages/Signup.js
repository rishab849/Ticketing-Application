import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Formik, Form as FormikForm, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import bcrypt from 'bcryptjs';
import '../css/Signup.css';

const SignUp = () => {
    const navigate = useNavigate();

    const handleBack = () => {
        navigate('/');
    };

    async function SignUpUser(values) {
        try {
            const password = bcrypt.hashSync(values.password, 2);
            const response = await fetch('http://localhost:5000/signup', {
                method: "POST",
                headers: {
                    'Content-type': "application/json"
                },
                body: JSON.stringify({ ...values, password })
            });
            const responseData = await response.json();
            if (responseData.success) {
                navigate('/home');
            } else {
                navigate('/signup');
            }
    
        } catch (error) {
            console.error('Error:', error);
        }
    }

    const validationSchema = Yup.object({
        firstname: Yup.string()
            .matches(/^[A-Za-z]+$/, 'Firstname must contain only alphabets')
            .required('Firstname is required'),
        lastname: Yup.string()
            .matches(/^[A-Za-z]+$/, 'Lastname must contain only alphabets')
            .required('Lastname is required'),
        phone: Yup.string()
            .matches(/^\d{10}$/, 'Phone number must be valid')
            .required('Phone is required'),
        email: Yup.string()
            .email('Invalid email address')
            .required('Email is required'),
        empId: Yup.string()
            .matches(/^\d{10}$/, 'Employee ID must contain exact 10 integers')
            .required('EMP ID is required'),
        password: Yup.string()
            .min(8, 'Password must be at least 8 characters')
            .required('Password is required'),
        confirmPassword: Yup.string()
            .oneOf([Yup.ref('password'), null], 'Passwords must match')
            .required('Confirm Password is required')
    });

    return (
        <div className="container">
            <div className="welcome-section">
                <h1>Welcome!</h1>
            </div>
            <div className="form-section">
                <h2>Hello! Please tell us a little bit about yourself.</h2>
                <Formik
                    initialValues={{
                        firstname: '',
                        lastname: '',
                        phone: '',
                        email: '',
                        empId: '',
                        password: '',
                        confirmPassword: ''
                    }}
                    validationSchema={validationSchema}
                    onSubmit={SignUpUser}
                >
                    {({ isSubmitting }) => (
                        <FormikForm>
                            <div className='short'>
                                <div className="input-group">
                                    <label>Firstname</label>
                                    <Field type="text" name="firstname" />
                                    <ErrorMessage name="firstname" component="div" className="error" />
                                </div>
                                <div className="input-group">
                                    <label>Lastname</label>
                                    <Field type="text" name="lastname" />
                                    <ErrorMessage name="lastname" component="div" className="error" />
                                </div>
                            </div>
                            <div className="input-group phone">
                                <label>Phone</label>
                                <Field type="text" name="phone" placeholder="+91" />
                                <ErrorMessage name="phone" component="div" className="error" />
                            </div>
                            <div className='short'>
                                <div className="input-group">
                                    <label>Email</label>
                                    <Field type="email" name="email" />
                                    <ErrorMessage name="email" component="div" className="error" />
                                </div>
                                <div className="input-group">
                                    <label>EMP ID</label>
                                    <Field type="text" name="empId" />
                                    <ErrorMessage name="empId" component="div" className="error" />
                                </div>
                            </div>
                            <div className='short'>
                                <div className="input-group">
                                    <label>Enter Password</label>
                                    <Field type="password" name="password" />
                                    <ErrorMessage name="password" component="div" className="error" />
                                </div>
                                <div className="input-group">
                                    <label>Confirm Password</label>
                                    <Field type="password" name="confirmPassword" />
                                    <ErrorMessage name="confirmPassword" component="div" className="error" />
                                </div>
                            </div>
                            <div className="button-group">
                                <button type="button" className="back-button" onClick={handleBack}>BACK</button>
                                <button type="submit" className="next-button" disabled={isSubmitting}>NEXT</button>
                            </div>
                        </FormikForm>
                    )}
                </Formik>
            </div>
        </div>
    );
};

export default SignUp