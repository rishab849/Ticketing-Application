import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import '../css/Dashboard.css';
import { Navbar, Sidebar } from '../components';

const Dashboard = () => {
  const [todayCount, setTodayCount] = useState(0);
  const [resolvedTodayCount, setResolvedTodayCount] = useState(0);
  const [resolvedCount, setResolvedCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [categoryCounts, setCategoryCounts] = useState([]);
  const [categories, setCategories] = useState({});
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchIncidentStats = async () => {
      try {
        const todayResponse = await axios.get('http://localhost:5000/incidents/today');
        setTodayCount(todayResponse.data[0]?.count || 0);

        const resolvedTodayResponse = await axios.get('http://localhost:5000/incidents/resolved-today');
        setResolvedTodayCount(resolvedTodayResponse.data[0]?.count || 0);

        const resolvedResponse = await axios.get('http://localhost:5000/incidents/resolved');
        setResolvedCount(resolvedResponse.data[0]?.count || 0);

        const totalResponse = await axios.get('http://localhost:5000/incidents/total');
        setTotalCount(totalResponse.data[0]?.count || 0);

        const categoryResponse = await axios.get('http://localhost:5000/incidents/category');
        setCategoryCounts(categoryResponse.data);

        const categoriesResponse = await axios.get('http://localhost:5000/categories');
        const categoryMap = categoriesResponse.data.reduce((acc, category) => {
          acc[category.id] = category.name;
          return acc;
        }, {});
        setCategories(categoryMap);
      } catch (error) {
        console.error('Error fetching incident stats:', error);
        setError('An error occurred while fetching incident stats.');
      }
    };

    fetchIncidentStats();
  }, []);

  const graphData = [
    { name: 'Today', created: todayCount, resolved: resolvedTodayCount }
  ];

  return (
    <div className="dash">
      <Navbar />
      <Sidebar />
      <div className="containerss">
        <h1 className="heading">Incident Stats</h1>
        {error && <p className="error">{error}</p>}
        <div className="stat-item">Incidents Created Today: <span className="stat">{todayCount}</span></div>
        <div className="stat-item">Incidents Resolved Today: <span className="stat">{resolvedTodayCount}</span></div>
        <div className="stat-item">Total Incidents: <span className="stat">{totalCount}</span></div>
        <div className="stat-item">Incidents Resolved: <span className="stat">{resolvedCount}</span></div>
        <h2 className="subHeading">Incidents by Category</h2>
        <ul className="list">
          {categoryCounts.map((category) => (
            <li key={category.category} className="listItem">
              {categories[category.category]}: {category.count}
            </li>
          ))}
        </ul>
        <h2 className="subHeading">Incident Graph</h2>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart
            width={500}
            height={300}
            data={graphData}
            margin={{
              top: 5, right: 30, left: 20, bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="created" fill="#8884d8" />
            <Bar dataKey="resolved" fill="#82ca9d" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Dashboard;
