import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { FaEdit, FaTrash } from 'react-icons/fa'; // Importing icons
import '../css/master.css';
import { Navbar, Sidebar } from '../components/index'; 
import { useNavigate } from 'react-router-dom';


function CategoryPage() {
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [subcategories, setSubcategories] = useState([]);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newSubcategoryName, setNewSubcategoryName] = useState('');
  const [editSubcategoryName, setEditSubcategoryName] = useState('');
  const [editSubcategoryId, setEditSubcategoryId] = useState(null);

  const [groups, setGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState('');
  const [people, setPeople] = useState([]);
  const [newGroupName, setNewGroupName] = useState('');
  const [newPersonName, setNewPersonName] = useState('');
  const [editPersonName, setEditPersonName] = useState('');
  const [editPersonId, setEditPersonId] = useState(null);

  const [impacts, setImpacts] = useState([]);
  const [newImpactName, setNewImpactName] = useState('');
  const [editImpactName, setEditImpactName] = useState('');
  const [editImpactId, setEditImpactId] = useState(null);

  const [urgencies, setUrgencies] = useState([]);
  const [newUrgencyName, setNewUrgencyName] = useState('');
  const [editUrgencyName, setEditUrgencyName] = useState('');
  const [editUrgencyId, setEditUrgencyId] = useState(null);

  const [statuses, setStatuses] = useState([]);
  const [newStatusName, setNewStatusName] = useState('');
  const [editStatusName, setEditStatusName] = useState('');
  const [editStatusId, setEditStatusId] = useState(null);

  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://localhost:5000/categories')
      .then(response => {
        setCategories(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the categories!', error);
      });
  }, []);

  useEffect(() => {
    axios.get('http://localhost:5000/impacts')
      .then(response => {
        setImpacts(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the impacts!', error);
      });
  }, []);

  useEffect(() => {
    axios.get('http://localhost:5000/urgencies')
      .then(response => {
        setUrgencies(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the urgencies!', error);
      });
  }, []);

  useEffect(() => {
    axios.get('http://localhost:5000/statuses')
      .then(response => {
        setStatuses(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the statuses!', error);
      });
  }, []);

  useEffect(() => {
    axios.get('http://localhost:5000/groups')
      .then(response => {
        setGroups(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the groups!', error);
      });
  }, []);

  const handleCategoryChange = (e) => {
    const categoryId = e.target.value;
    setSelectedCategory(categoryId);
    if (categoryId) {
      axios.get(`http://localhost:5000/subcategories/${categoryId}`)
        .then(response => {
          setSubcategories(response.data);
        })
        .catch(error => {
          console.error('There was an error fetching the subcategories!', error);
        });
    } else {
      setSubcategories([]);
    }
  };

  const handleGroupChange = (e) => {
    const groupId = e.target.value;
    setSelectedGroup(groupId);
    if (groupId) {
      axios.get(`http://localhost:5000/people/${groupId}`)
        .then(response => {
          setPeople(response.data);
        })
        .catch(error => {
          console.error('There was an error fetching the people!', error);
        });
    } else {
      setPeople([]);
    }
  };

  const handleAddCategory = () => {
    axios.post('http://localhost:5000/categories', { name: newCategoryName })
      .then(response => {
        setCategories([...categories, response.data]);
        setNewCategoryName('');
      })
      .catch(error => {
        console.error('There was an error adding the category!', error);
      });
  };

  const handleAddSubcategory = () => {
    axios.post('http://localhost:5000/subcategories', { name: newSubcategoryName, category_id: selectedCategory })
      .then(response => {
        setSubcategories([...subcategories, response.data]);
        setNewSubcategoryName('');
      })
      .catch(error => {
        console.error('There was an error adding the subcategory!', error);
      });
      navigate('/master');
  };

  const handleEditSubcategory = (id, name) => {
    setEditSubcategoryId(id);
    setEditSubcategoryName(name);
    navigate('/master');
  };

  const handleSaveEditSubcategory = () => {
    axios.put(`http://localhost:5000/subcategories/${editSubcategoryId}`, { name: editSubcategoryName })
      .then(response => {
        setSubcategories(subcategories.map(subcategory => subcategory.id === editSubcategoryId ? response.data : subcategory));
        setEditSubcategoryId(null);
        setEditSubcategoryName('');
      })
      .catch(error => {
        console.error('There was an error editing the subcategory!', error);
      });
      navigate('/master');
  };

  const handleDeleteSubcategory = (id) => {
    axios.delete(`http://localhost:5000/subcategories/${id}`)
      .then(response => {
        setSubcategories(subcategories.filter(subcategory => subcategory.id !== id));
      })
      .catch(error => {
        console.error('There was an error deleting the subcategory!', error);
      });
      navigate('/master');
  };

  const handleAddImpact = () => {
    axios.post('http://localhost:5000/impacts', { name: newImpactName })
      .then(response => {
        setImpacts([...impacts, response.data]);
        setNewImpactName('');
      })
      .catch(error => {
        console.error('There was an error adding the impact!', error);
      });
      navigate('/master');
  };

  const handleEditImpact = (id, name) => {
    setEditImpactId(id);
    setEditImpactName(name);
    navigate('/master');
  };

  const handleSaveEditImpact = () => {
    axios.put(`http://localhost:5000/impacts/${editImpactId}`, { name: editImpactName })
      .then(response => {
        setImpacts(impacts.map(impact => impact.id === editImpactId ? response.data : impact));
        setEditImpactId(null);
        setEditImpactName('');
      })
      .catch(error => {
        console.error('There was an error editing the impact!', error);
      });
      navigate('/master');
  };

  const handleDeleteImpact = (id) => {
    axios.delete(`http://localhost:5000/impacts/${id}`)
      .then(response => {
        setImpacts(impacts.filter(impact => impact.id !== id));
      })
      .catch(error => {
        console.error('There was an error deleting the impact!', error);
      });
      navigate('/master');
  };

  const handleAddUrgency = () => {
    axios.post('http://localhost:5000/urgencies', { name: newUrgencyName })
      .then(response => {
        setUrgencies([...urgencies, response.data]);
        setNewUrgencyName('');
      })
      .catch(error => {
        console.error('There was an error adding the urgency!', error);
      });
      navigate('/master');
  };

  const handleEditUrgency = (id, name) => {
    setEditUrgencyId(id);
    setEditUrgencyName(name);
    navigate('/master');
  };

  const handleSaveEditUrgency = () => {
    axios.put(`http://localhost:5000/urgencies/${editUrgencyId}`, { name: editUrgencyName })
      .then(response => {
        setUrgencies(urgencies.map(urgency => urgency.id === editUrgencyId ? response.data : urgency));
        setEditUrgencyId(null);
        setEditUrgencyName('');
      })
      .catch(error => {
        console.error('There was an error editing the urgency!', error);
      });
      navigate('/master');
  };

  const handleDeleteUrgency = (id) => {
    axios.delete(`http://localhost:5000/urgencies/${id}`)
      .then(response => {
        setUrgencies(urgencies.filter(urgency => urgency.id !== id));
      })
      .catch(error => {
        console.error('There was an error deleting the urgency!', error);
      });
      navigate('/master');
  };

  const handleAddStatus = () => {
    axios.post('http://localhost:5000/statuses', { name: newStatusName })
      .then(response => {
        setStatuses([...statuses, response.data]);
        setNewStatusName('');
      })
      .catch(error => {
        console.error('There was an error adding the status!', error);
      });
      navigate('/master');
  };

  const handleEditStatus = (id, name) => {
    setEditStatusId(id);
    setEditStatusName(name);
    navigate('/master');
  };

  const handleSaveEditStatus = () => {
    axios.put(`http://localhost:5000/statuses/${editStatusId}`, { name: editStatusName })
      .then(response => {
        setStatuses(statuses.map(status => status.id === editStatusId ? response.data : status));
        setEditStatusId(null);
        setEditStatusName('');
      })
      .catch(error => {
        console.error('There was an error editing the status!', error);
      });
      navigate('/master');
  };

  const handleDeleteStatus = (id) => {
    axios.delete(`http://localhost:5000/statuses/${id}`)
      .then(response => {
        setStatuses(statuses.filter(status => status.id !== id));
      })
      .catch(error => {
        console.error('There was an error deleting the status!', error);
      });
      navigate('/master');
  };

  const handleAddGroup = () => {
    axios.post('http://localhost:5000/groups', { name: newGroupName })
      .then(response => {
        setGroups([...groups, response.data]);
        setNewGroupName('');
      })
      .catch(error => {
        console.error('There was an error adding the group!', error);
      });
  };

  const handleAddPerson = () => {
    axios.post('http://localhost:5000/people', { name: newPersonName, group_id: selectedGroup })
      .then(response => {
        setPeople([...people, response.data]);
        setNewPersonName('');
      })
      .catch(error => {
        console.error('There was an error adding the person!', error);
      });
      navigate('/master');
  };

  const handleEditPerson = (id, name) => {
    setEditPersonId(id);
    setEditPersonName(name);
    navigate('/master');
  };

  const handleSaveEditPerson = () => {
    axios.put(`http://localhost:5000/people/${editPersonId}`, { name: editPersonName })
      .then(response => {
        setPeople(people.map(person => person.id === editPersonId ? response.data : person));
        setEditPersonId(null);
        setEditPersonName('');
      })
      .catch(error => {
        console.error('There was an error editing the person!', error);
      });
      navigate('/master');
  };

  const handleDeletePerson = (id) => {
    axios.delete(`http://localhost:5000/people/${id}`)
      .then(response => {
        setPeople(people.filter(person => person.id !== id));
      })
      .catch(error => {
        console.error('There was an error deleting the person!', error);
      });
      navigate('/master');
  };

  return (
    <div className="category-page">
        <Navbar />
        <Sidebar />
      <h1 className="category-page__title">Master Page</h1>

      <select className="category-page__select" value={selectedCategory} onChange={handleCategoryChange}>
        <option value="">Select Category</option>
        {categories.map(category => (
          <option key={category.id} value={category.id}>{category.name}</option>
        ))}
      </select>

      {selectedCategory && (
        <div>
          <div className="category-page__input-group">
            <input
              className="category-page__input"
              type="text"
              placeholder="New Subcategory Name"
              value={newSubcategoryName}
              onChange={(e) => setNewSubcategoryName(e.target.value)}
            />
            <button className="category-page__button" onClick={handleAddSubcategory}>Add Subcategory</button>
          </div>

          <table className="category-page__table">
            <thead>
              <tr>
                <th>Subcategory</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {subcategories.map(subcategory => (
                <tr key={subcategory.id}>
                  <td>
                    {editSubcategoryId === subcategory.id ? (
                      <input
                        type="text"
                        value={editSubcategoryName}
                        onChange={(e) => setEditSubcategoryName(e.target.value)}
                      />
                    ) : (
                      subcategory.name
                    )}
                  </td>
                  <td>
                    {editSubcategoryId === subcategory.id ? (
                      <button onClick={handleSaveEditSubcategory}>Save</button>
                    ) : (
                      <>
                        <FaEdit className="category-page__icon" onClick={() => handleEditSubcategory(subcategory.id, subcategory.name)} />
                        <FaTrash className="category-page__icon" onClick={() => handleDeleteSubcategory(subcategory.id)} />
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

<select className="category-page__select" value={selectedGroup} onChange={handleGroupChange}>
        <option value="">Select Group</option>
        {groups.map(group => (
          <option key={group.id} value={group.id}>{group.name}</option>
        ))}
</select>
{selectedGroup && (
        <div>
          <div className="category-page__input-group">
            <input
              className="category-page__input"
              type="text"
              placeholder="New Person"
              value={newPersonName}
              onChange={(e) => setNewPersonName(e.target.value)}
            />
            <button className="category-page__button" onClick={handleAddPerson}>Add Person</button>
          </div>

          <table className="category-page__table">
            <thead>
              <tr>
                <th>People</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {people.map(people => (
                <tr key={people.id}>
                  <td>
                    {editSubcategoryId === people.id ? (
                      <input
                        type="text"
                        value={editPersonName}
                        onChange={(e) => setEditPersonName(e.target.value)}
                      />
                    ) : (
                      people.name
                    )}
                  </td>
                  <td>
                    {editPersonId === people.id ? (
                      <button onClick={handleSaveEditPerson}>Save</button>
                    ) : (
                      <>
                        <FaEdit className="category-page__icon" onClick={() => handleEditPerson(people.id, people.name)} />
                        <FaTrash className="category-page__icon" onClick={() => handleDeletePerson(people.id)} />
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <h2>Impact Management</h2>
      <div className="category-page__input-group">
        <input
          className="category-page__input"
          type="text"
          placeholder="New Impact Name"
          value={newImpactName}
          onChange={(e) => setNewImpactName(e.target.value)}
        />
        <button className="category-page__button" onClick={handleAddImpact}>Add Impact</button>
      </div>

      <table className="category-page__table">
        <thead>
          <tr>
            <th>Impact</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {impacts.map(impact => (
            <tr key={impact.id}>
              <td>
                {editImpactId === impact.id ? (
                  <input
                    type="text"
                    value={editImpactName}
                    onChange={(e) => setEditImpactName(e.target.value)}
                  />
                ) : (
                  impact.name
                )}
              </td>
              <td>
                {editImpactId === impact.id ? (
                  <button onClick={handleSaveEditImpact}>Save</button>
                ) : (
                  <>
                    <FaEdit className="category-page__icon" onClick={() => handleEditImpact(impact.id, impact.name)} />
                    <FaTrash className="category-page__icon" onClick={() => handleDeleteImpact(impact.id)} />
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Urgency Management</h2>
      <div className="category-page__input-group">
        <input
          className="category-page__input"
          type="text"
          placeholder="New Urgency Name"
          value={newUrgencyName}
          onChange={(e) => setNewUrgencyName(e.target.value)}
        />
        <button className="category-page__button" onClick={handleAddUrgency}>Add Urgency</button>
      </div>

      <table className="category-page__table">
        <thead>
          <tr>
            <th>Urgency</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {urgencies.map(urgency => (
            <tr key={urgency.id}>
              <td>
                {editUrgencyId === urgency.id ? (
                  <input
                    type="text"
                    value={editUrgencyName}
                    onChange={(e) => setEditUrgencyName(e.target.value)}
                  />
                ) : (
                  urgency.name
                )}
              </td>
              <td>
                {editUrgencyId === urgency.id ? (
                  <button onClick={handleSaveEditUrgency}>Save</button>
                ) : (
                  <>
                    <FaEdit className="category-page__icon" onClick={() => handleEditUrgency(urgency.id, urgency.name)} />
                    <FaTrash className="category-page__icon" onClick={() => handleDeleteUrgency(urgency.id)} />
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2>Status Management</h2>
      <div className="category-page__input-group">
        <input
          className="category-page__input"
          type="text"
          placeholder="New Status Name"
          value={newStatusName}
          onChange={(e) => setNewStatusName(e.target.value)}
        />
        <button className="category-page__button" onClick={handleAddStatus}>Add Status</button>
      </div>

      <table className="category-page__table">
        <thead>
          <tr>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {statuses.map(status => (
            <tr key={status.id}>
              <td>
                {editStatusId === status.id ? (
                  <input
                    type="text"
                    value={editStatusName}
                    onChange={(e) => setEditStatusName(e.target.value)}
                  />
                ) : (
                  status.name
                )}
              </td>
              <td>
                {editStatusId === status.id ? (
                  <button onClick={handleSaveEditStatus}>Save</button>
                ) : (
                  <>
                    <FaEdit className="category-page__icon" onClick={() => handleEditStatus(status.id, status.name)} />
                    <FaTrash className="category-page__icon" onClick={() => handleDeleteStatus(status.id)} />
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CategoryPage;
