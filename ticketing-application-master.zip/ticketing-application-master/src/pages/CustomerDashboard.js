import React from 'react';
import '../css/style.css'; 

import group43 from '../assets/Group 43.png';
import attention1 from '../assets/attention 1.png';
import browseCatalog from '../assets/8564381621649742464 1.png';
import knowledgeBase from '../assets/knowledge 2.png';
import { Navbar, Sidebar } from '../components/index'; 

const CustomerDashboard = () => {
  return (
    <div>
      <Navbar />
      <Sidebar />
      <img src={group43} class="image"></img>

      <div className="center">
        <p className="one">GIVE YOUR</p>
        <span className="one">Problem </span>
        <span className="one">RAISED</span>
        <p className="four"><a href="newIncident">Click Here To Need Help</a></p>
      </div>

      <div class="cards">
        <div class="card">
          <img src={attention1}></img>
          <h3><a href="/newIncident" className='link'>Submit Incident</a></h3>
          <p>Use this for submit incident</p>
        </div>
        <div class="card">
          <img src={browseCatalog}></img>
          <h3><a>Browse Catalog</a></h3>
          <p>Use this for submiting request</p>
        </div>
        <div class="card">
          <img src={knowledgeBase}></img>
          <h3><a>Knowledge Base</a></h3>
          <p class="new">Use this for searching knowledge articles</p>
        </div>
      </div>


      <div className="tag">
        <div className="tags"><h2><a>My Requests</a></h2></div>
        <div className="tags"><h2><a>My Approvals</a></h2></div>
        <div className="tags"><h2><a href="/ann">Announcement</a></h2></div>
      </div>

      <footer className="footer">
        <p>@design by ess team</p>
      </footer>
    </div>
  );
};

export default CustomerDashboard;
