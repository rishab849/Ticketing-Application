import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import '../css/form.css'; // Updated CSS file name
import { Navbar, Sidebar } from '../components';
import { useNavigate } from 'react-router-dom';

const EditIncident = () => {
  const { inc_number } = useParams();
  const [incident, setIncident] = useState({});
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [impacts, setImpacts] = useState([]);
  const [urgencies, setUrgencies] = useState([]);
  const [groups, setGroups] = useState([]);
  const [people, setPeople] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const navigate = useNavigate();

  useEffect(() => {
    const fetchIncident = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/inc/${inc_number}`);
        setIncident(response.data[0]);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching incident:', error);
      }
    };

    const fetchData = async () => {
      try {
        const [
          categoriesRes,
          subcategoriesRes,
          statusesRes,
          impactsRes,
          urgenciesRes,
          groupsRes,
          peopleRes,
        ] = await Promise.all([
          axios.get('http://localhost:5000/categories'),
          axios.get('http://localhost:5000/subcategories'),
          axios.get('http://localhost:5000/statuses'),
          axios.get('http://localhost:5000/impacts'),
          axios.get('http://localhost:5000/urgencies'),
          axios.get('http://localhost:5000/groups'),
          axios.get('http://localhost:5000/people'),
        ]);
        setCategories(categoriesRes.data);
        setSubcategories(subcategoriesRes.data);
        setStatuses(statusesRes.data);
        setImpacts(impactsRes.data);
        setUrgencies(urgenciesRes.data);
        setGroups(groupsRes.data);
        setPeople(peopleRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchIncident();
    fetchData();
  }, [inc_number]);

  const handleChange = (e) => {
    setIncident({ ...incident, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/inc/${incident.inc_number}`, incident);
      alert('Incident updated successfully');
    } catch (error) {
      console.error('Error updating incident:', error);
    }
    navigate('/view') 
  };

  const getNameById = (id, data) => {
    const item = data.find((d) => d.id === id);
    return item ? item.name : '';
  };

  if (loading) {
    return <div className="loading-screen">Loading...</div>;
  }

  return (
    <div className="edit-incident-page">
      <Navbar />
      <Sidebar />
      <div className="edit-incident-containers">
        <form onSubmit={handleSubmit}>
          <h2 className="form-titles">Edit Incident</h2>
          <div className="form-rows">
            <label className="form-labels">Incident Number</label>
            <input
              type="text"
              name="inc_number"
              value={incident.inc_number}
              disabled
              className="form-inputs"
            />
          </div>
          <div className="form-rows">
            <label className="form-labels">Reported For</label>
            <input
              type="text"
              name="reported_for"
              value={incident.reported_for}
              onChange={handleChange}
              className="form-inputs"
            />
          </div>
          <div className="form-rows">
            <label className="form-labels">Location</label>
            <input
              type="text"
              name="location"
              value={incident.location}
              onChange={handleChange}
              className="form-inputs"
            />
          </div>
          <div className="form-rows">
            <label className="form-labels">Status</label>
            <select
              name="status"
              value={incident.status}
              onChange={handleChange}
              className="form-selects"
            >
              {statuses.map((status) => (
                <option key={status.id} value={status.id}>
                  {status.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-rows">
            <label className="form-labels">Impact</label>
            <select
              name="impacts"
              value={incident.impact}
              onChange={handleChange}
              className="form-selects"
            >
              {impacts.map((impact) => (
                <option key={impact.id} value={impact.id}>
                  {impact.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-rows">
            <label className="form-labels">Urgency</label>
            <select
              name="urgency"
              value={incident.urgency}
              onChange={handleChange}
              className="form-selects"
            >
              {urgencies.map((urgency) => (
                <option key={urgency.id} value={urgency.id}>
                  {urgency.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-rows">
            <label className="form-labels">Source</label>
            <input
              type="text"
              name="source"
              value={incident.source}
              onChange={handleChange}
              className="form-inputs"
            />
          </div>
          <div className="form-rows">
            <label className="form-labels">Priority</label>
            <input
              type="text"
              name="priority"
              value={incident.priority}
              onChange={handleChange}
              className="form-inputs"
            />
          </div>
          <div className="form-rows">
            <label className="form-labels">Category</label>
            <select
              name="category"
              value={incident.category}
              onChange={handleChange}
              className="form-selects"
            >
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-rows">
            <label className="form-labels">Subcategory</label>
            <select
              name="subcategory"
              value={incident.subcategory}
              onChange={handleChange}
              className="form-selects"
            >
              {subcategories.map((subcategory) => (
                <option key={subcategory.id} value={subcategory.id}>
                  {subcategory.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-rows">
            <label className="form-labels">Assigned Group</label>
            <select
              name="assign_group"
              value={incident.assign_group}
              onChange={handleChange}
              className="form-selects"
            >
              {groups.map((group) => (
                <option key={group.id} value={group.id}>
                  {group.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-rows">
            <label className="form-labels">Assigned To</label>
            <select
              name="assign_to"
              value={incident.assign_to}
              onChange={handleChange}
              className="form-selects"
            >
              {people.map((person) => (
                <option key={person.id} value={person.id}>
                  {person.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-rows">
            <label className="form-labels">Short Description</label>
            <textarea
              name="short_description"
              value={incident.short_description}
              onChange={handleChange}
              className="form-textareas"
            />
          </div>
          <div className="form-rows">
            <label className="form-labels">Long Description</label>
            <textarea
              name="long_description"
              value={incident.long_description}
              onChange={handleChange}
              className="form-textareas"
            />
          </div>
          <button type="submit" className="submit-buttons">
            Save Changes
          </button>
        </form>
      </div>
    </div>
  );
};

export default EditIncident;
