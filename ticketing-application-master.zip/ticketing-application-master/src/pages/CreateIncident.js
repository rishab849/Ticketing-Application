import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../css/inc.css';
import { Navbar, Sidebar } from '../components/index';
import { useNavigate } from 'react-router-dom';


const NewIncidentForm = () => {
  const [incidentNumber, setIncidentNumber] = useState('');
  const [formData, setFormData] = useState({
    reported_for: '',
    location: '',
    status: '',
    source:'',
    assign_group: '',
    assign_to: '',
    short_description: '',
    long_description: '',
    source: '',
    impact: '',
    urgency: '',
    priority: 'Priority',
    category: '',
    subcategory: ''
  });

  const [impacts, setImpacts] = useState([]);
  const [urgencies, setUrgencies] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [categories, setCategories] = useState([]);
  const [groups, setGroups] = useState([]);
  const [people, setPeople] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState('');
  const [impactName, setImpactName] = useState('');
  const [urgencyName, setUrgencyName] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const impactsResponse = await axios.get('http://localhost:5000/impacts');
        setImpacts(impactsResponse.data);

        const urgenciesResponse = await axios.get('http://localhost:5000/urgencies');
        setUrgencies(urgenciesResponse.data);

        const statusesResponse = await axios.get('http://localhost:5000/statuses');
        setStatuses(statusesResponse.data);

        const categoriesResponse = await axios.get('http://localhost:5000/categories');
        setCategories(categoriesResponse.data);

        const groupsResponse = await axios.get('http://localhost:5000/groups');
        setGroups(groupsResponse.data);

        const peopleResponse = await axios.get('http://localhost:5000/people');
        setPeople(peopleResponse.data);

        if (selectedCategoryId) {
          const subcategoriesResponse = await axios.get(`http://localhost:5000/subcategories/${selectedCategoryId}`);
          setSubcategories(subcategoriesResponse.data);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [selectedCategoryId]);

  const Priority = (impactName, urgencyName) => {
    if (impactName === 'Low' && urgencyName === 'Low') return 'Low';
    if (impactName === 'Low' && urgencyName === 'Medium') return 'Low';
    if (impactName === 'Low' && urgencyName === 'High') return 'Medium';
    if (impactName === 'Medium' && urgencyName === 'Low') return 'Low';
    if (impactName === 'Medium' && urgencyName === 'Medium') return 'Medium';
    if (impactName === 'Medium' && urgencyName === 'High') return 'High';
    if (impactName === 'High' && urgencyName === 'Low') return 'Medium';
    if (impactName === 'High' && urgencyName === 'Medium') return 'High';
    if (impactName === 'High' && urgencyName === 'High') return 'Critical';
    return 'Priority';
  };

  const handleChange = async (e) => {
    const { name, value } = e.target;
    setFormData((prevFormData) => {
      const updatedFormData = {
        ...prevFormData,
        [name]: value
      };

      return updatedFormData;
    });

    if (name === 'impact' || name === 'urgency') {
      let newImpactName = impactName;
      let newUrgencyName = urgencyName;

      if (name === 'impact') {
        const impact = impacts.find(imp => imp.id === parseInt(value));
        newImpactName = impact ? impact.name : '';
        setImpactName(newImpactName);
      }

      if (name === 'urgency') {
        const urgency = urgencies.find(urg => urg.id === parseInt(value));
        newUrgencyName = urgency ? urgency.name : '';
        setUrgencyName(newUrgencyName);
      }

      const newPriority = Priority(newImpactName, newUrgencyName);
      setFormData((prevFormData) => ({
        ...prevFormData,
        priority: newPriority
      }));
    }

    if (name === 'category') {
      setSelectedCategoryId(value);
      setFormData((prevFormData) => ({
        ...prevFormData,
        sub_category: ''
      }));
    }

    if (name === 'assign_group') {
      setSelectedGroupId(value);
      setFormData((prevFormData) => ({
        ...prevFormData,
        assign_to: ''
      }));
    }
  };

  axios.get('http://localhost:5000/next-incident-number')
            .then(response => {
                setIncidentNumber(response.data.nextIncidentNumber);
            })
            .catch(error => {
                console.error('There was an error fetching the next incident number!', error);
            });
        


            const handleSubmit = (e) => {
              e.preventDefault();
              axios.post('http://localhost:5000/incidents', { ...formData, inc_number: incidentNumber })
                  .then(response => {
                      alert(response.data.message);
                  })
                  .catch(error => {
                      console.error('There was an error!', error);
                  });
                  navigate('/view')
          };
  return (
    <div className="page-container">
      <Navbar />
      <Sidebar />
      <div className='news'>
        <div className='container'>
          <div className="form-container">
            <header className="form-header">
              <h1>New Incident</h1>
            </header>
            <form className="incident-form" onSubmit={handleSubmit}>
              <div className="row">
                <section className="section requester-details">
                  <h2>Requester Details</h2>
                  <div className="form-group">
                    <label>Incident Number</label>
                    <input type="text" name="inc_number" value={incidentNumber} readOnly />
                  </div>
                  <div className="form-group">
                    <label>Reported For</label>
                    <div className="input-with-icon">
                      <input type="text" name="reported_for" placeholder="reported for" value={formData.reported_for} onChange={handleChange} />
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Reported For Location</label>
                    <div className="input-with-icon">
                      <input type="text" name="location" placeholder="reported for location" value={formData.location} onChange={handleChange} />
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Status</label>
                    <select name="status" value={formData.status} onChange={handleChange}>
                      <option value="">Status</option>
                      {statuses.map((status) => (
                        <option key={status.id} value={status.id}>{status.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>State</label>
                    <input type="text" name="state" value={formData.state} onChange={handleChange} readOnly />
                  </div>
                </section>
                <section className="section assign-details">
                  <h2>Assign Details</h2>
                  <div className="form-group">
                    <label>Assign Group</label>
                    <select name="assign_group" value={formData.assign_group} onChange={handleChange}>
                      <option value="">Assign Group</option>
                      {groups.map((group) => (
                        <option key={group.id} value={group.id}>{group.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Assign To</label>
                    <select name="assign_to" value={formData.assign_to} onChange={handleChange}>
                      <option value="">Assign To</option>
                      {people.filter(person => person.group_id === parseInt(selectedGroupId)).map((person) => (
                        <option key={person.id} value={person.id}>{person.name}</option>
                      ))}
                    </select>
                  </div>
                </section>
                <section className="section ci-details">
                  <h2>CI Details</h2>
                  <div className="form-group">
                    <label>Configuration Item</label>
                    <select name="configuration_item" value={formData.configuration_item} onChange={handleChange}>
                      <option value="">Configuration Item</option>
                      {/* Add options for configuration items here */}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Impacted Service</label>
                    <select name="impacted_service" value={formData.impacted_service} onChange={handleChange}>
                      <option value="">Impacted Service</option>
                      {/* Add options for impacted services here */}
                    </select>
                  </div>
                </section>
              </div>
              <div className="row">
                <section className="section categorization">
                  <h2>Categorization</h2>
                  <div className="form-group">
                    <label>Source</label>
                    <select name="source" value={formData.source} onChange={handleChange}>
                      <option value=''>Source</option>
                      <option value="Office">Office</option>
                      <option value="Email">Email</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Impact</label>
                    <select name="impact" value={formData.impact} onChange={handleChange}>
                      <option value="">Impact</option>
                      {impacts.map((impact) => (
                        <option key={impact.id} value={impact.id}>{impact.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Urgency</label>
                    <select name="urgency" value={formData.urgency} onChange={handleChange}>
                      <option value="">Urgency</option>
                      {urgencies.map((urgency) => (
                        <option key={urgency.id} value={urgency.id}>{urgency.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Priority</label>
                    <input type="text" name="priority" value={formData.priority} readOnly />
                  </div>
                  <div className="form-group">
                    <label>Category</label>
                    <select name="category" value={formData.category} onChange={handleChange}>
                      <option value="">Category</option>
                      {categories.map((category) => (
                        <option key={category.id} value={category.id}>{category.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="form-group">
  <label>Sub Category</label>
  <select name="subcategory" value={formData.subcategory} onChange={handleChange}>
    <option value="">Sub Category</option>
    {subcategories.map((subcategory) => (
      <option key={subcategory.id} value={subcategory.id}>{subcategory.name}</option>
    ))}
  </select>
</div>

                </section>
                <section className="section summary">
                  <h2>Summary</h2>
                  <div className="form-group label-textarea">
                    <label>Short Description</label>
                    <textarea name="short_description" placeholder="short info" value={formData.short_description} onChange={handleChange} ></textarea>
                  </div>
                  <div className="form-group label-textarea">
                    <label>Description</label>
                    <textarea name="long_description" placeholder="full info" className='long' value={formData.long_description} onChange={handleChange}></textarea>
                  </div>
                </section>
              </div>
              <div className="form-footer">
                <button type="submit" className="save-button">SAVE</button>
                <button type="submit" className="submit-buttons">SUBMIT</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewIncidentForm;
