import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../css/view.css';
import { Navbar, Sidebar } from '../components/index';

const IncidentCards = () => {
  const [incidents, setIncidents] = useState([]);
  const [statuses, setStatuses] = useState({});
  const [groups, setGroups] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const incidentsResponse = await axios.get('http://localhost:5000/incidents');
        setIncidents(incidentsResponse.data);

        const statusesResponse = await axios.get('http://localhost:5000/statuses');
        const statusMap = {};
        statusesResponse.data.forEach(status => {
          statusMap[status.id] = status.name;
        });
        setStatuses(statusMap);

        const groupsResponse = await axios.get('http://localhost:5000/groups');
        const groupMap = {};
        groupsResponse.data.forEach(group => {
          groupMap[group.id] = group.name;
        });
        setGroups(groupMap);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();

    // Dynamically add FontAwesome
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css';
    document.head.appendChild(link);

    return () => {
      document.head.removeChild(link);
    };
  }, []);

  const handleEditClick = (incidentId) => {
    // const incidentNumber = incidents.find(incident => incident.id === incidentId).inc_number;
    const incidentNumber =incidentId
    navigate(`/edit/${incidentNumber}`);
  };

  return (
    <div>
      <Navbar />
      <Sidebar />
      <div className="incident-page">
        {incidents.map((incident) => (
          <div key={incident.id} className="incident-card">
            <div className="incident-details">
              <p><strong>Incident Number:</strong> {incident.inc_number}</p>
              <p><strong>Status:</strong> {statuses[incident.status] || 'Unknown'}</p> {/* Map status ID to name */}
              <p><strong>Assigned Group:</strong> {groups[incident.assign_group] || 'Unknown'}</p>
              <p><strong>Priority:</strong> {incident.priority}</p>
              <p><strong>Time:</strong> {new Date(incident.date).toLocaleString()}</p>
              <p><strong>Short Description:</strong> {incident.short_description}</p>
            </div>
            <button className="edit-button" onClick={() => handleEditClick(incident.inc_number)}>
              <i className="fas fa-pencil-alt"></i>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default IncidentCards;
