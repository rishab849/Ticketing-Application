import React from 'react';
import '../../node_modules/bootstrap/dist/css/bootstrap.css';
import '../css/fulfillerdashboard.css'; // Assuming this is where your custom styles are defined
import { Navbar, Sidebar } from '../components/index'; // Assuming these are your custom components

const FulfillerDashboard = () => {
  return (
    <div className='bg'>
      <Navbar />
      <Sidebar />

      <div className='bg-img'>
        <div className="container">
          <div className="main">
            <h2><span className="bordered-text">IT</span></h2>
            <h2><span className="bordered-text">SUPPORT</span></h2>
            <h2><span className="bordered-text">MANAGEMENT</span></h2>
          </div>
        </div>
      </div>
        <div className="side">
          <div className="ann">
            <h2 style={{ color: 'white' }}>Announcement</h2>
            <p className="mt">&lt; 2 of 15 &gt;</p>
          </div>
          <p className="text">Lorem ipsum dolor sit amet consectetur. Proin quam faucibus amet morbi bibendum enim.</p>
          <div className="ann">
            <p className="mt">Maintenance</p>
            <p className="mt"> 2 Days Ago</p>
          </div>
          <hr />
          <p className="text">Lorem ipsum dolor sit amet consectetur. Proin quam faucibus amet morbi bibendum enim.</p>
          <div className="ann">
            <p className="mt">Maintenance</p>
            <p className="mt"> 3 Days Ago</p>
          </div>
        </div>
      </div>
  );
};

export default FulfillerDashboard;
