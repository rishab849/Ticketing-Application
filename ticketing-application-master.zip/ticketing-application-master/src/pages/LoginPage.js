import React, { useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import { jwtDecode } from "jwt-decode"; // Corrected import
import '../css/login.css';

const Login = () => {
  const loginEmailRef = useRef();
  const loginPasswordRef = useRef();
  const navigate = useNavigate();

  useEffect(() => {
    const checkTokenExpiration = () => {
      const tokenExpiration = localStorage.getItem('tokenExpiration');
      if (tokenExpiration && new Date().getTime() > tokenExpiration) {
        localStorage.removeItem('token');
        localStorage.removeItem('tokenExpiration');
        navigate('/');
      } else if (tokenExpiration) {
        setSessionTimeout();
      }
    };

    checkTokenExpiration();
  }, [navigate]);

  const formik = useFormik({
    initialValues: {
      emailOrEmpId: '',
      password: '',
      rememberMe: false,
    },
    validationSchema: Yup.object({
      emailOrEmpId: Yup.string()
        .required('Email or Employee ID is required')
        .test(
          'is-valid',
          'Invalid Email or Employee ID',
          (value) => {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const empIdRegex = /^\d{10}$/;
            return emailRegex.test(value) || empIdRegex.test(value);
          }
        ),
      password: Yup.string()
        .required('Password is required')
        .min(4, 'Password must be at least 8 characters long'),
    }),
    onSubmit: (values) => {
      login(values.emailOrEmpId, values.password);
    },
  });

  const setSessionTimeout = () => {
    const expirationTime = localStorage.getItem('tokenExpiration');
    const timeout = expirationTime - new Date().getTime();

    setTimeout(() => {
      localStorage.removeItem('token');
      localStorage.removeItem('tokenExpiration');
      navigate('/');
    }, timeout);
  };

  const login = async (emailOrEmpId, password) => {
    try {
      const response = await fetch('http://localhost:5000/login', {
        method: "POST",
        headers: {
          'Content-type': "application/json"
        },
        body: JSON.stringify({ email: emailOrEmpId, password })
      });
      const responseData = await response.json();
      if (response.ok) {
        const token = responseData.token;
        const decodedToken = jwtDecode(token); // Corrected usage
        console.log('JWT Token:', decodedToken); // Print the decoded JWT token to the console
        const expirationTime = new Date().getTime() + 3600000; // 1 hour from now
        localStorage.setItem('token', token);
        localStorage.setItem('tokenExpiration', expirationTime);
        setSessionTimeout();
        navigate('/home');
      } else {
        console.log('Login failed:', responseData.message);
        formik.resetForm();
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="div">
      <div className="div-2">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/4b1ce4a780142a1931b0612d44ee88d06de17b7a35013d12d6a27e4655996fb4?apiKey=c77c050625aa4090ac1d3352f0717ba7&"
          className="img"
          alt="Background"
        />
        <div className="div-3">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/8bd38f5853e450332aaa35a6e31a517d1d7612dca2fcf806f423f10bf6f7fbb7?apiKey=c77c050625aa4090ac1d3352f0717ba7&"
            className="img"
            alt="Logo"
          />
          <div className="div-4">
            <img
              loading="lazy"
              srcSet="https://cdn.builder.io/api/v1/image/assets/TEMP/1374631cae7440457ae24457ff606ce82f565ac30afc28318752c06964cb8606?apiKey=c77c050625aa4090ac1d3352f0717ba7&width=100 100w, https://cdn.builder.io/api/v1/image/assets/TEMP/1374631cae7440457ae24457ff606ce82f565ac30afc28318752c06964cb8606?apiKey=c77c050625aa4090ac1d3352f0717ba7&width=200 200w, https://cdn.builder.io/api/v1/image/assets/TEMP/1374631cae7440457ae24457ff606ce82f565ac30afc28318752c06964cb8606?apiKey=c77c050625aa4090ac1d3352f0717ba7&width=400 400w, https://cdn.builder.io/api/v1/image/assets/TEMP/1374631cae7440457ae24457ff606ce82f565ac30afc28318752c06964cb8606?apiKey=c77c050625aa4090ac1d3352f0717ba7&width=800 800w, https://cdn.builder.io/api/v1/image/assets/TEMP/1374631cae7440457ae24457ff606ce82f565ac30afc28318752c06964cb8606?apiKey=c77c050625aa4090ac1d3352f0717ba7&width=1200 1200w, https://cdn.builder.io/api/v1/image/assets/TEMP/1374631cae7440457ae24457ff606ce82f565ac30afc28318752c06964cb8606?apiKey=c77c050625aa4090ac1d3352f0717ba7&width=1600 1600w, https://cdn.builder.io/api/v1/image/assets/TEMP/1374631cae7440457ae24457ff606ce82f565ac30afc28318752c06964cb8606?apiKey=c77c050625aa4090ac1d3352f0717ba7&width=2000 2000w, https://cdn.builder.io/api/v1/image/assets/TEMP/1374631cae7440457ae24457ff606ce82f565ac30afc28318752c06964cb8606?apiKey=c77c050625aa4090ac1d3352f0717ba7&"
              className="img-2"
              alt="Pic"
            />
            <div className="div-5">
              <span style={{ fontFamily: "Poppins, sans-serif", fontWeight: 500 }}>
                Join us and become member of
              </span>
              <br />
              <span style={{ fontFamily: "Poppins, sans-serif", fontWeight: 700 }}>
                ESS Incident
              </span>
              <span style={{ fontFamily: "Poppins, sans-serif", fontWeight: 300 }}>
                management
              </span>
            </div>
            <form onSubmit={formik.handleSubmit}>
              <input
                type="text"
                id="emailOrEmpId"
                placeholder="Enter your email or Emp ID"
                ref={loginEmailRef}
                className="input-field div-6"
                value={formik.values.emailOrEmpId}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.emailOrEmpId && formik.errors.emailOrEmpId ? (
                <div className="error">{formik.errors.emailOrEmpId}</div>
              ) : null}
              <input
                type="password"
                id="password"
                className="input-field div-7"
                placeholder="Enter your password"
                ref={loginPasswordRef}
                value={formik.values.password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.password && formik.errors.password ? (
                <div className="error">{formik.errors.password}</div>
              ) : null}
              <div className="div-8">
                <div className="div-9">
                  <div className="div-10">
                    <div className="div-11">
                      <label className="switch">
                        <input
                          type="checkbox"
                          name="rememberMe"
                          checked={formik.values.rememberMe}
                          onChange={formik.handleChange}
                        />
                        <span className="slider round"></span>
                      </label>
                    </div>
                    <div className="div-13">Remember me</div>
                  </div>
                  <div className="div-14">
                    <a href="/signup" className="signup-link">Sign Up</a>
                    <span> | </span>
                    <a href="/forgot-password" className="forgot-password-link">Forgot Password</a>
                  </div>
                </div>
                <button type="submit" className="div-15">SIGN IN</button>
              </div>
            </form>
            <div className="div-16">Powered By ESS Team</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
