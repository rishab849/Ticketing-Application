const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const app = express();
require('dotenv').config();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

app.use(cors());
app.use(express.json());

const secretKey = "qwertyuiopasdfghjklzxcvbnmm"; 

// MySQL connection
const db = mysql.createConnection({
  host: process.env.DB_HOST || '127.0.0.1',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'ess',
  timezone: 'Z'
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Connected to the database');
});

// Generic query handler
const queryHandler = (sql, params, res) => {
  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('SQL Error:', err);
      res.status(500).json({ error: 'Internal server error', details: err.message });
    } else {
      res.json(results);
    }
  });
};

// Middleware to validate request body for required fields
const validateRequestBody = (requiredFields) => {
  return (req, res, next) => {
    for (const field of requiredFields) {
      if (!req.body[field]) {
        return res.status(400).json({ error: `Missing required field: ${field}` });
      }
    }
    next();
  };
};

// Routes for categories and subcategories
app.get('/categories', (req, res) => {
  const sql = 'SELECT id, name FROM categories';
  queryHandler(sql, [], res);
});

app.get('/subcategories', (req, res) => {
  const sql = 'SELECT id, category_id, name FROM subcategories';
  queryHandler(sql, [], res);
});

app.get('/subcategories/:categoryId', (req, res) => {
  const sql = 'SELECT id, name FROM subcategories WHERE category_id = ?';
  queryHandler(sql, [req.params.categoryId], res);
});

app.post('/categories', validateRequestBody(['name']), (req, res) => {
  const sql = 'INSERT INTO categories (name) VALUES (?)';
  queryHandler(sql, [req.body.name], res);
});

app.post('/subcategories', validateRequestBody(['name', 'category_id']), (req, res) => {
  const sql = 'INSERT INTO subcategories (name, category_id) VALUES (?, ?)';
  queryHandler(sql, [req.body.name, req.body.category_id], res);
});

app.put('/subcategories/:id', validateRequestBody(['name']), (req, res) => {
  const sql = 'UPDATE subcategories SET name = ? WHERE id = ?';
  queryHandler(sql, [req.body.name, req.params.id], res);
});

app.delete('/subcategories/:id', (req, res) => {
  const sql = 'DELETE FROM subcategories WHERE id = ?';
  queryHandler(sql, [req.params.id], res);
});

// Routes for impacts
app.get('/impacts', (req, res) => {
  const sql = 'SELECT id, name FROM impact';
  queryHandler(sql, [], res);
});

app.post('/impacts', validateRequestBody(['name']), (req, res) => {
  const sql = 'INSERT INTO impact (name) VALUES (?)';
  queryHandler(sql, [req.body.name], res);
});

app.put('/impacts/:id', validateRequestBody(['name']), (req, res) => {
  const sql = 'UPDATE impact SET name = ? WHERE id = ?';
  queryHandler(sql, [req.body.name, req.params.id], res);
});

app.delete('/impacts/:id', (req, res) => {
  const sql = 'DELETE FROM impact WHERE id = ?';
  queryHandler(sql, [req.params.id], res);
});

// Routes for urgencies
app.get('/urgencies', (req, res) => {
  const sql = 'SELECT id, name FROM urgency';
  queryHandler(sql, [], res);
});

app.post('/urgencies', validateRequestBody(['name']), (req, res) => {
  const sql = 'INSERT INTO urgency (name) VALUES (?)';
  queryHandler(sql, [req.body.name], res);
});

app.put('/urgencies/:id', validateRequestBody(['name']), (req, res) => {
  const sql = 'UPDATE urgency SET name = ? WHERE id = ?';
  queryHandler(sql, [req.body.name, req.params.id], res);
});

app.delete('/urgencies/:id', (req, res) => {
  const sql = 'DELETE FROM urgency WHERE id = ?';
  queryHandler(sql, [req.params.id], res);
});

// Routes for statuses
app.get('/statuses', (req, res) => {
  const sql = 'SELECT id, name FROM status';
  queryHandler(sql, [], res);
});

app.post('/statuses', validateRequestBody(['name']), (req, res) => {
  const sql = 'INSERT INTO status (name) VALUES (?)';
  db.query(sql, [req.body.name], (err, results) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(400).json({ error: 'Duplicate entry. This status already exists.' });
      }
      return res.status(500).json({ error: 'Internal server error', details: err.message });
    }
    res.json({ id: results.insertId, name: req.body.name });
  });
});

app.put('/statuses/:id', validateRequestBody(['name']), (req, res) => {
  const sql = 'UPDATE status SET name = ? WHERE id = ?';
  queryHandler(sql, [req.body.name, req.params.id], res);
});

app.delete('/statuses/:id', (req, res) => {
  const sql = 'DELETE FROM status WHERE id = ?';
  queryHandler(sql, [req.params.id], res);
});

// Routes for groups and people
app.get('/groups', (req, res) => {
  const sql = 'SELECT id, name FROM `group`';
  queryHandler(sql, [], res);
});

app.get('/people', (req, res) => {
  const sql = 'SELECT id, group_id, name FROM people';
  queryHandler(sql, [], res);
});

app.get('/people/:groupId', (req, res) => {
  const sql = 'SELECT id, name FROM people WHERE group_id = ?';
  queryHandler(sql, [req.params.groupId], res);
});

app.post('/groups', validateRequestBody(['name']), (req, res) => {
  const sql = 'INSERT INTO `group` (name) VALUES (?)';
  queryHandler(sql, [req.body.name], res);
});

app.post('/people', validateRequestBody(['name', 'group_id']), (req, res) => {
  const sql = 'INSERT INTO people (name, group_id) VALUES (?, ?)';
  queryHandler(sql, [req.body.name, req.body.group_id], res);
});

app.put('/people/:id', validateRequestBody(['name']), (req, res) => {
  const sql = 'UPDATE people SET name = ? WHERE id = ?';
  queryHandler(sql, [req.body.name, req.params.id], res);
});

app.delete('/people/:id', (req, res) => {
  const sql = 'DELETE FROM people WHERE id = ?';
  queryHandler(sql, [req.params.id], res);
});

// Get next incident number
const getNextIncidentNumber = (callback) => {
  db.query('SELECT inc_number FROM incident ORDER BY inc_number DESC LIMIT 1', (err, result) => {
    if (err) {
      return callback(err, null);
    }
    if (result.length > 0) {
      const lastIncNumber = result[0].inc_number;
      const lastNumber = parseInt(lastIncNumber.slice(3), 10);
      const nextNumber = 'INC' + String(lastNumber + 1).padStart(6, '0');
      callback(null, nextNumber);
    } else {
      callback(null, 'INC000001');
    }
  });
};

// Endpoint to get the next incident number
app.get('/next-incident-number', (req, res) => {
  getNextIncidentNumber((err, nextIncidentNumber) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ nextIncidentNumber });
  });
});

// Insert incident
app.post('/incidents',  (req, res) => {
  const { inc_number, reported_for, location, status, impact, urgency, source, priority, category, subcategory, assign_group, assign_to, short_description, long_description } = req.body;

  const sql = 'INSERT INTO incident (inc_number, reported_for, location, status, impact, urgency, source, priority, category, subcategory, assign_group, assign_to, short_description, long_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  const values = [inc_number, reported_for, location, status, impact, urgency, source, priority, category, subcategory, assign_group, assign_to, short_description, long_description];

  db.query(sql, values, (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: 'New record created successfully' });
  });
});

// Update an incident
app.put('/inc/:inc_number', (req, res) => {
  const { reported_for, location, status, impact, urgency, source, priority, category, subcategory, assign_group, assign_to, short_description, long_description } = req.body;
  const sql = 'UPDATE incident SET reported_for = ?, location = ?, status = ?, impact = ?, urgency = ?, source = ?, priority = ?, category = ?, subcategory = ?, assign_group = ?, assign_to = ?, short_description = ?, long_description = ? WHERE inc_number = ?';
  const values = [reported_for, location, status, impact, urgency, source, priority, category, subcategory, assign_group, assign_to, short_description, long_description, req.params.inc_number];

  db.query(sql, values, (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: `Incident with number ${req.params.inc_number} updated successfully` });
  });
});

// Fetch incidents
app.get('/incidents', (req, res) => {
  const sql = 'SELECT * FROM incident';
  queryHandler(sql, [], res);
});

// Fetch a single incident by number
app.get('/inc/:inc_number', (req, res) => {
  const sql = 'SELECT * FROM incident WHERE inc_number = ?';
  queryHandler(sql, [req.params.inc_number], res);
});

// Fetch total number of incidents created today
app.get('/incidents/today', (req, res) => {
  const sql = `
    SELECT COUNT(*) AS count
    FROM incident
    WHERE DATE(CONVERT_TZ(date, @@session.time_zone, '+05:30')) = CURDATE() AND status = 1
  `;
  queryHandler(sql, [], res);
});

// Fetch total number of incidents resolved today
app.get('/incidents/resolved-today', (req, res) => {
  const sql = `
    SELECT COUNT(*) AS count
    FROM incident
    WHERE status = 3 AND DATE(CONVERT_TZ(date, @@session.time_zone, '+05:30')) = CURDATE()
  `;
  queryHandler(sql, [], res);
});

// Fetch total number of incidents resolved today
app.get('/incidents/resolved', (req, res) => {
  const sql = `
    SELECT COUNT(*) AS count
    FROM incident
    WHERE status = 3
  `;
  queryHandler(sql, [], res);
});

// Fetch total number of incidents
app.get('/incidents/total', (req, res) => {
  const sql = `
    SELECT COUNT(*) AS count
    FROM incident
  `;
  queryHandler(sql, [], res);
});

// Fetch total number of incidents received for each category
app.get('/incidents/category', (req, res) => {
  const sql = `
    SELECT category, COUNT(*) AS count
    FROM incident
    GROUP BY category
  `;
  queryHandler(sql, [], res);
});

// Fetch incident data for graph (incidents received today and solved today)
app.get('/incidents/graph-data', (req, res) => {
  const receivedTodaySql = `
    SELECT COUNT(*) AS count
    FROM incident
    WHERE DATE(CONVERT_TZ(date, @@session.time_zone, '+05:30')) = CURDATE()
  `;
  const solvedTodaySql = `
    SELECT COUNT(*) AS count
    FROM incident
    WHERE status = 'resolved' AND DATE(CONVERT_TZ(date, @@session.time_zone, '+05:30')) = CURDATE()
  `;

  db.query(receivedTodaySql, (err, receivedResults) => {
    if (err) {
      console.error('SQL Error (receivedTodaySql):', err);
      return res.status(500).json({ error: 'Internal server error', details: err });
    }

    db.query(solvedTodaySql, (err, solvedResults) => {
      if (err) {
        console.error('SQL Error (solvedTodaySql):', err);
        return res.status(500).json({ error: 'Internal server error', details: err });
      }

      res.json({
        receivedToday: receivedResults[0].count,
        solvedToday: solvedResults[0].count,
      });
    });
  });
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  const query = "SELECT password FROM users WHERE email = ?";

  db.query(query, [email], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: "Database error" });
    }
    if (results.length === 0) {
      return res.status(400).json({ message: "User not found" });
    }

    const hashedPassword = results[0].password;
    if (!bcrypt.compareSync(password, hashedPassword)) {
      return res.status(400).json({ message: "Invalid password" });
    }

    const token = jwt.sign({ email }, secretKey, { expiresIn: "1h" });
    res.status(200).json({ message: "Login successful", token });
  });
});

app.post("/signup", (req, res) => {
  const { firstname, lastname, phone, email, empId, password } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);
  const query = "INSERT INTO signup (firstName, lastName, phone, email, emp_id, password) VALUES (?, ?, ?, ?, ?, ?)";
  const loginQuery = "INSERT INTO users (email, password) VALUES (?, ?)";

  db.query(query, [firstname, lastname, phone, email, empId, hashedPassword], (err, result) => {
    if (err) {
      console.error("Error signing up user:", err);
      return res.json({ success: false, error: "Failed to sign up user" });
    }

    db.query(loginQuery, [email, hashedPassword], (err, result) => {
      if (err) {
        console.error("Error inserting user while signing up:", err);
        return res.json({ success: false, error: "Failed to insert user(signup)" });
      }
      res.json({ success: true, message: "User signed up successfully" });
    });
  });
});

const authenticateToken = (req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, secretKey, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

app.get("/protected", authenticateToken, (req, res) => {
  res.json({ message: "This is a protected route", user: req.user });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
